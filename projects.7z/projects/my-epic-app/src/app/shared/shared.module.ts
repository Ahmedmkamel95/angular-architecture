import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import {MatButtonModule} from '@angular/material/button';
import {MatCardModule} from '@angular/material/card';

@NgModule({
  declarations: [],
  imports: [
    RouterModule,
    CommonModule,

    //material
    MatCardModule,
    MatButtonModule,
  ],
  exports:[
    RouterModule,
    CommonModule,

    //material
    MatCardModule,
    MatButtonModule,
  ]
})
export class SharedModule { }
